<?php
 class Muzyka_Helper_Date extends Zend_View_Helper_Abstract
 {
 	public function date()
 	{
 			echo 'ok';
 	}
 }