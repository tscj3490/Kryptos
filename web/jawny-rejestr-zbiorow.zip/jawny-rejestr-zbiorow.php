<?php

header('Content-Type: text/html; charset=utf-8');

$serverName = $_SERVER['SERVER_NAME'];

$apiUri = 'http://' . $serverName . '/api/jawny-rejestr-zbiorow';
$cacheFile = 'jawny-rejestr-zbiorow.dat';
$disableCache = true;

if ($disableCache || !is_file($cacheFile)) {
    $json = file_get_contents($apiUri);
    file_put_contents($cacheFile, $json);
} else {
    $json = file_get_contents($cacheFile);
}

if (!$json) {
    exit;
}

$data = json_decode($json, true);

?>
<style>
.demo > div {
    width:1000px;
    margin:auto;
}
#kryptos-jawny-rejestr-zbiorow .zbior-element {
    box-sizing: border-box;
}
#kryptos-jawny-rejestr-zbiorow .zbior-element .zbior-naglowek > span:first-child +span {
    border-bottom:1px dashed #c7c0cb;
}
#kryptos-jawny-rejestr-zbiorow .zbior-element:last-child .zbior-naglowek > span:first-child +span {
    border-bottom:0;
}
#kryptos-jawny-rejestr-zbiorow .zbior-naglowek {
    background-color: #DF0D8C;
}
#kryptos-jawny-rejestr-zbiorow .zbior-naglowek > span:first-child {
    display: inline-block;
    width:100px;
    position: absolute;
    cursor:pointer;
    color:white;
    padding:10px;
    line-height:30px;
    box-sizing: border-box;
}
#kryptos-jawny-rejestr-zbiorow .zbior-naglowek > span:first-child +span {
    margin-left:100px;
    display:block;
    min-height:50px;
    line-height:30px;
    padding:10px 0 10px 50px;
    box-sizing: border-box;
    background-color: white;
}
#kryptos-jawny-rejestr-zbiorow .zbior-dane {
    display:none;
}
#kryptos-jawny-rejestr-zbiorow .zbior-dane ul {
    list-style:none;
    padding:0;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-preview-wrapper {
    background:white;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-preview .zbior-dane {
    display:block;
}
#kryptos-jawny-rejestr-zbiorow table {
    border-collapse:collapse;
}
#kryptos-jawny-rejestr-zbiorow table td {
    border-collapse:collapse;
    padding:7px 10px;
}
#kryptos-jawny-rejestr-zbiorow table tr + tr td + td {
    border-top:1px dashed #c7c0cb;
}
#kryptos-jawny-rejestr-zbiorow table td:first-child {
    background-color: #DF0D8C;
    color:white;
    text-align: center;
    padding:7px 4px;
}
#kryptos-jawny-rejestr-zbiorow table td:first-child + td {
    width:45%;
}
#kryptos-jawny-rejestr-zbiorow .hidden {
    display:none;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-page {
    float:left;
    /*display:none;*/
}
#kryptos-jawny-rejestr-zbiorow .rejestr-page.active {
    /*display:block;*/
}
#kryptos-jawny-rejestr-zbiorow .rejestr-window {
    position:relative;
    overflow:hidden;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-window > div {
    position:absolute;
    top:0;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-preview {
    position:absolute;
    left:0;
    right:0;
    z-index: 9999;
    overflow: hidden;
    height:0;
    box-sizing: border-box;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-preview-close,
#kryptos-jawny-rejestr-zbiorow .rejestr-paginator-next,
#kryptos-jawny-rejestr-zbiorow .rejestr-paginator-prev {
    display:inline-block;
    padding: 0 10px;
    line-height:40px;
    height:40px;
    font-weight: bold;
    background-color: #DF0D8C;
    color:white;
    cursor:pointer;
}
#kryptos-jawny-rejestr-zbiorow .zbior-element {
    cursor: pointer;
}
#kryptos-jawny-rejestr-zbiorow .zbior-element:hover .zbior-naglowek > span:first-child + span {
    background: #f2f2f2;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-paginator {
    margin-top:25px;
    text-align:center;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-paginator-next {
    float:right;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-paginator-prev {
    float:left;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-paginator-summary {
    margin:0 100px;
    display:block;
    line-height:40px;
    height:40px;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-preview-navigation {
    text-align: center;
    padding:10px;
}
#kryptos-jawny-rejestr-zbiorow table tr:first-child td {
    padding-top:25px;
}
#kryptos-jawny-rejestr-zbiorow table tr:last-child td {
    padding-bottom:25px;
}
#kryptos-jawny-rejestr-zbiorow h1 {
    text-align:center;
    margin-bottom:40px;
}
#kryptos-jawny-rejestr-zbiorow .rejestr-current-page input {
    width:30px;
    height:30px;
    border:1px solid #DF0D8C;
    text-align:center;
}
</style>
<div class="demo">
    <div id="kryptos-jawny-rejestr-zbiorow">
        <div class="header"><h1>Jawny rejestr zbiorów</h1></div>
        <div class="rejestr-window">
            <div class="rejestr-scroller">
                <div class="rejestr-page active">
                    <?php foreach ($data as $i => $zbior): ?>
                        <div class="zbior-element <?= $i > 9 ? 'hidden' : '' ?>">
                            <div class="zbior-naglowek">
                        <span>
                            <span class="">ZDO <?= $zbior['id'] ?></span>
                        </span>
                        <span>
                            <span class=""><?= $zbior['name'] ?></span>
                        </span>
                            </div>
                            <div class="zbior-dane">
                                <table>
                                    <tr>
                                        <td>1</td>
                                        <td>Nazwa zbioru danych:</td>
                                        <td><?= $zbior['name'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Oznaczenie administratora danych i adres jego siedziby lub miejsca zamieszkania oraz numer identyfikacyjny rejestru podmiotów gospodarki narodowej, jeżeli został mu nadany:</td>
                                        <td><?= $zbior['data_admin'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Oznaczenie przedstawiciela administratora danych, o którym mowa w art. 3la ustawy i adres jego siedziby lub miejsca zamieszkania - w przypadku wyznaczenia takego podmiotu:</td>
                                        <td><?= $zbior['data_admin_agent'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>4</td>
                                        <td>Oznaczenie podmiotu, któremu powierzono przetwarzanie danych ze zbioru na podstawie art. 31 ustawy i adres jego siedziby lub miejsca zamieszkania w przypadku powierzenia przetwarzania danych temu podmiotowi:</td>
                                        <td><?= $zbior['entruster'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>5</td>
                                        <td>Podstawa prawna upoważniająca do prowadzenia zbioru danych:</td>
                                        <td><?= $zbior['process_legal_basis'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>6</td>
                                        <td>Cel przetwarzania danych w zbiorze:</td>
                                        <td><?= $zbior['process_purpose'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>7</td>
                                        <td>Opis kategorii osób, których dane są przetwarzane w zbiorze:</td>
                                        <td><?= $zbior['process_persons'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>8</td>
                                        <td>Zakres danych przetwarzanych w zbiorze:</td>
                                        <td><?= $zbior['process_metadata'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>9</td>
                                        <td>Sposób zbierania danych do zbioru w szczególności informacja czy dane do zbioru są zbierane od osób, których dotyczą, czy z innych źródeł niż osoba, której dane dotyczą:</td>
                                        <td><?= $zbior['collecting_description'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>10</td>
                                        <td>Sposób udostępniania danych ze zbioru, w szczególności informacja czy dane ze zbioru są udostępniane  podmiotom innym niż upoważnione na podstawie przepisów prawa:</td>
                                        <td><?= $zbior['sharing_description'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>11</td>
                                        <td>Oznaczenie odbiorcy danych lub kategorii odbiorców, którym dane mogą być przekazywane:</td>
                                        <td><?= $zbior['send_description'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>12</td>
                                        <td>Informacja dotycząca ewentualnego przekazywania danych do państwa trzeciego:</td>
                                        <td><?= $zbior['other_country_description'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>13</td>
                                        <td>Data wpisania zbioru do rejestru:</td>
                                        <td><?= $zbior['created_at'] ?></td>
                                    </tr>
                                    <tr>
                                        <td>14</td>
                                        <td>Data dokonania ostatniej aktualizacji:</td>
                                        <td><?= $zbior['updated_at'] ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    <?php endforeach ?>
                </div>
            </div>
            <div class="rejestr-preview">
                <div class="rejestr-preview-wrapper">
                    <div class="rejestr-preview-navigation">
                        <span class="rejestr-preview-close">powrót</span>
                    </div>
                    <div class="rejestr-preview-data"></div>
                    <div class="rejestr-preview-navigation">
                        <span class="rejestr-preview-close">powrót</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="rejestr-paginator">
            <a class="rejestr-paginator-prev">poprzednia</a>
            <a class="rejestr-paginator-next">następna</a>
            <span class="rejestr-paginator-summary"><span class="rejestr-current-page"><input value="1"/></span> strona z <span class="rejestr-last-page">1</span></span>
        </div>
    </div>
</div>
<script type="text/javascript" src="assets/plugins/jquery/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
(function(){
    if (typeof jQuery !== 'undefined') {
        var $ = jQuery,
            currentPage = 1,
            pageMax = 10,
            rejestr = $('#kryptos-jawny-rejestr-zbiorow'),
            windowElement = rejestr.find('.rejestr-window'),
            windowScroller = windowElement.find('.rejestr-scroller'),
            windowPreview = windowElement.find('.rejestr-preview'),
            windowPreviewWrapper = windowElement.find('.rejestr-preview-wrapper'),
            cfgAnimationDuration = 300,
            cfgAnimationEasing = 'swing';

        windowPreview.find('.rejestr-preview-close').on('click', closePreview);
        windowPreview.hide();

        $('#kryptos-jawny-rejestr-zbiorow .zbior-element').on('click', openPreview);
        $('#kryptos-jawny-rejestr-zbiorow .rejestr-current-page input').on('input keyup paste', changePage);

        function openPreview() {
            var dataElement = $(this).find('.zbior-naglowek').next(),
                currentHeight = windowElement.height();

            windowPreviewWrapper.css('opacity', 0);
            windowPreview
                .find('.rejestr-preview-data')
                .html(dataElement.clone());
            windowPreview
                .css('height', 'auto')
                .show();

            var previewHeight = windowPreview.height();
            windowElement.animate({height: previewHeight}, cfgAnimationDuration, cfgAnimationEasing);
            windowPreview
                .css('top', currentHeight / 2)
                .animate({height:previewHeight, top: 0}, cfgAnimationDuration / 2, cfgAnimationEasing);
            windowPreviewWrapper.animate({opacity: 1}, cfgAnimationDuration / 2, cfgAnimationEasing);

        }
        function closePreview() {
            windowPreviewWrapper.animate({opacity: 0}, cfgAnimationDuration / 2, cfgAnimationEasing);
            windowPreview.animate({height: 0, top: windowScroller.children('.active').height() / 2}, cfgAnimationDuration / 2, cfgAnimationEasing, function() {
                windowPreview.hide();
            });

            resizeWindow();
        }

        var nextButton = rejestr.find('.rejestr-paginator-next'),
            prevButton = rejestr.find('.rejestr-paginator-prev');

        var elements = $('.zbior-element'),
            contents = $('.zbior-dane'),
            counter = elements.size(),
            lastPage = Math.ceil(counter / pageMax);

        rejestr.find('.rejestr-last-page').text(lastPage);

        distributePages();
        var windowPages = windowScroller.children();

        resizeWindow(true);

        if (counter > pageMax) {
            nextButton.show();
        }
        prevButton.hide();

        function distributePages() {
            var tmpPage = 1,
                tmpElements,
                pageElement,
                elementStart;

            while (++tmpPage <= lastPage) {
                elementStart = (tmpPage - 1) * pageMax;
                tmpElements = elements.slice(elementStart, elementStart + pageMax);
                pageElement = $('<div class="rejestr-page">');
                tmpElements
                    .appendTo(pageElement)
                    .removeClass('hidden');
                pageElement.appendTo(windowScroller);
            }
        }

        function resizeWindow(initialize) {
            var activeElement = windowScroller.children('.active'),
                width = windowElement.width(),
                height = activeElement.height();

            windowPages.css({
                width: width
            });

            windowElement
                .css({width: width});

            if (initialize) {
                windowElement.css({height: height});
            } else {
                windowElement.animate({height: height}, cfgAnimationDuration, cfgAnimationEasing);
            }

            windowScroller.css({
                width: width * windowPages.size(),
                height: height
            });
        }

        function setCurrentPageText() {
            rejestr.find('.rejestr-current-page input').val(currentPage);
        }

        function prevPage() {
            if (currentPage < 2) {
                return;
            }

            currentPage--;
            windowScroller
                .children('.active')
                .removeClass('active')
                .prev()
                .addClass('active');
            windowScroller.animate({
                left: '+=' +  windowElement.width()
            }, cfgAnimationDuration, cfgAnimationEasing, function() {
                if (currentPage === 1) {
                    prevButton.hide();
                }
                nextButton.show();

                setCurrentPageText();
                resizeWindow();
            });

            closePreview();
        }

        function nextPage() {
            if (currentPage >= lastPage) {
                return;
            }

            currentPage++;
            windowScroller
                .children('.active')
                .removeClass('active')
                .next()
                .addClass('active');
            windowScroller.animate({
                left: '-=' +  windowElement.width()
            }, cfgAnimationDuration, cfgAnimationEasing, function() {
                if (currentPage === lastPage) {
                    nextButton.hide();
                }
                prevButton.show();

                setCurrentPageText();
                resizeWindow();
            });

            closePreview();
        }

        function changePage() {
            var selectedPageValue = $(this).val();

            if (selectedPageValue === '') {
                return;
            }
            var selectedPage = parseInt(selectedPageValue);

            if (selectedPageValue !== selectedPage.toString()) {
                selectedPage = 1;
            }

            if (selectedPage < 0) {
                selectedPage = 1;
            } else if (selectedPage > lastPage) {
                selectedPage = lastPage;
            }

            var scrollByWidth = (currentPage - selectedPage) * windowElement.width();

            currentPage = selectedPage;
            $(this).val(currentPage);

            windowScroller
                .children('.active')
                .removeClass('active')
                .end()
                .children()
                .eq(currentPage - 1)
                .addClass('active');

            windowScroller.animate({
                left: '+=' +  scrollByWidth
            }, cfgAnimationDuration, cfgAnimationEasing, function() {
                prevButton.show();
                nextButton.show();
                if (currentPage === lastPage) {
                    nextButton.hide();
                }
                if (currentPage === 1) {
                    prevButton.hide();
                }

                setCurrentPageText();
                resizeWindow();
            });
        }

        prevButton.click(prevPage);
        nextButton.click(nextPage);

    }
})();
</script>
